<?php
    error_reporting(E_ALL ^ E_NOTICE);
    date_default_timezone_set('Asia/Manila');
    session_set_cookie_params(0);
    session_start();

    // if(!$_SESSION['idno']){ header('location:../actions/logout.php'); }
    require_once 'dbconn.php';
    $dbconn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $dbconn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    $dbconn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);


    if (!$dbconn)
    {
      die("ERROR: Unable to connect to database.");
    }


    if (isset($_POST['login'])) {
        $ok = 1;
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        // $stmt = $dbconn->prepare("SELECT COUNT(*) FROM account where username=? and password=? and verify='1'");
        // $stmt->bindParam(1, $username);
        // $stmt->bindParam(2, $password);
        // $stmt->execute();
        // $count = $stmt->fetchColumn();

        // if ($count >= 1) {

            $stmt = $dbconn->prepare("SELECT * from account where username=? and password=?");
            $stmt->bindParam(1, $username);
            $stmt->bindParam(2, $password);
            $stmt->execute();
            // $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $_SESSION['id'] = $result['id'];
            $_SESSION['type'] = $result['account_type'];
            $_SESSION['username'] = $result['username'];
            $_SESSION['email'] = $result['email'];
            $_SESSION['password'] = $result['password'];

            if ($result['account_type'] == '00') {
                echo "<script>alert('Welcome Admin ".$username."');</script>";
                echo "<script>window.location = '../Admin/';</script>";
            }elseif($result['account_type'] == '01'){
                echo "<script>alert('Welcome User to Mabisa ".$username."');</script>";
                echo "<script>window.location = '../User/';</script>";
            }else{
                // echo "<script>alert('Welcome User To Mabisa ".$username."');</script>";
                // echo "<script>window.location = '../User/';</script>";
                echo "<script>window.location = '../';</script>";
            }
        // }else{
        //     $alert = 'Incorrect Username and password or Email not verify. Please try again later.';
        // }
    }
?>
<script type="text/javascript">
    alert('<?php echo $alert ?>');
    window.location = '../';
</script>