<?php
$host = "localhost";
$dbname = "mabisa_orig";
$username = "root";
$password = "";

// $host = "localhost";
// $dbname = "u525844616_mabisa";
// $username = "u525844616_mabisa";
// $password = "Salindo!@#$%^&*()1234567890";