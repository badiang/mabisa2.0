<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                <!-- <nav class="navbar navbar-expand navbar-light bg-primary topbar mb-4 static-top shadow"> -->

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <!-- <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form> -->
                    <style type="text/css">
                        @media screen and (max-width: 600px) {
                              .mobile_hide {
                                display: none;
                              }
                            }
                    </style>
                    <h4 class="mobile_hide" style="text-transform: uppercase;"><b>Mabilisang Aksyon Barangay Information System of Aloran</b></h4>
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <!-- <span class="mr-2 d-none d-lg-inline text-gray-600 small">Douglas McGee</span> -->
                                <span class="mr-2 d-none d-lg-inline small" style="color: black;"><b><?php echo $_SESSION['username'] ?></b></span>
                                <img class="img-profile rounded-circle"
                                    src="../img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <!-- <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a> -->
                                <!-- <div class="dropdown-divider"></div> -->
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#email">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Email
                                </a>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#username">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Change Username
                                </a>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#passwordModal2">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Change Password
                                </a>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>

<!-- Logout Modal-->
    <div class="modal fade" id="passwordModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="alert_password2"></div>
                    <div class="form-group">
                        <label for="current_password21">Current Password:</label>
                        <input type="password" class="form-control form-control-user" id="current_password21" name="current_password21" autocomplete="off">
                        <input type="text" class="form-control form-control-user" id="current_password22" name="current_password22" value="<? echo $_SESSION['password'] ?>" hidden>
                    </div>
                    <div class="form-group">
                        <label for="new_password2">New Password:</label>
                        <input type="password" class="form-control form-control-user"
                            id="new_password2" name="new_password2">
                    </div>
                    <div class="form-group">
                        <label for="confirm_password2">Re-entered New Password:</label>
                        <input type="password" class="form-control form-control-user"
                            id="confirm_password2" name="confirm_password2">
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" onclick="confirm_password22()">Confirm</a>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function confirm_password22() {
            ok = 1;
            current_password = $('#current_password21').val();
            current_password2 = $('#current_password22').val();
            new_password2 = $('#new_password2').val();
            confirm_password2 = $('#confirm_password2').val();
            // alert(current_password2);
            if (current_password != current_password2) {
                $('#alert_password2').html('<span style="color: red;">Incorrect Current Password.</span>');
                ok = 0;
            }
            if (new_password2 != confirm_password2) {
                $('#alert_password2').html('<span style="color: red;">2 password not match.</span>');
                ok = 0;
            }
            if (new_password2.length < 8) {
                $('#alert_password2').html('<span style="color: red;">Password must atleast 8 letters or numbers.</span>');
                ok = 0;
            }

            if (ok == 1) {
                $.ajax({
                    type: "POST",
                    url: "../User/actions/password_email.php",
                    async: false,
                    data: {
                        new_password: new_password2,
                        confirm_password: confirm_password2,
                        change: 1
                    },
                    success:function(result){
                        $('#alert_password2').html('<span style="color: green;">Password Successfully change.</span>');
                    }
                });
            }
        }
    </script>

    <div class="modal fade" id="email" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="alert_password23"></div>
                    <div class="form-group">
                        <label for="change_email">Email:</label>
                        <input type="email" class="form-control form-control-user"
                            id="change_email" name="change_email" value="<?php echo $_SESSION['email'] ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" onclick="confirm_email()">Confirm</a>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function confirm_email() {
            change_email = $('#change_email').val();
            $.ajax({
                type: "POST",
                url: "actions/change_email.php",
                async: false,
                data: {
                    change_email: change_email,
                    change: 1
                },
                success:function(result){
                    $('#alert_password23').html('<span style="color: green;">Email Successfully Updated.</span>');
                }
            });
        }
    </script>

    <div class="modal fade" id="username" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Change Username</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="alert_username"></div>
                    <div class="form-group">
                        <label for="change_username">Username:</label>
                        <input type="text" class="form-control form-control-user"
                            id="change_username" name="change_username" value="<?php echo $_SESSION['username'] ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" onclick="confirm_username()">Confirm</a>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        function confirm_username() {
            change_username = $('#change_username').val();

            $.ajax({
                type: "POST",
                url: "actions/change_username.php",
                async: false,
                data: {
                    change_username: change_username,
                    change: 1
                },
                success:function(result){
                    $('#alert_username').html('<span style="color: green;">Username Successfully Updated.</span>');
                }
            });

        }
    </script>